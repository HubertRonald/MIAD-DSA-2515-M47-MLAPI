from typing import Any, List, Optional

from pydantic import BaseModel
from model.processing.validation import DataInputSchema

# Esquema de los resultados de predicción
class PredictionResults(BaseModel):
    errors: Optional[Any]
    version: str
    predictions: Optional[List[float]]

# Esquema para inputs múltiples
class MultipleDataInputs(BaseModel):
    inputs: List[DataInputSchema]

    class Config:
        schema_extra = {
            "example": {
                "inputs": [
                    {
                        "Customer_Age": 57,
                        "Total_Amt_Chng_Q4_Q1": 0.712,
                        "Total_Relationship_Count": 2,
                        "Total_Revolving_Bal": 0,
                        "Total_Ct_Chng_Q4_Q1": 0.843,
                        "Total_Trans_Ct": 94,
                        "Total_Trans_Amt": 7794,
                        "Months_Inactive_12_mon": 3,
                        "Contacts_Count_12_mon": 2
                    }
                ]
            }
        }
